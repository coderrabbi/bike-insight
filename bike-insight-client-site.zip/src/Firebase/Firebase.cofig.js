// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCAWi8R4nYvUFnwjElvSsAlj2FbvrqRrL8",
  authDomain: "bike-insight.firebaseapp.com",
  projectId: "bike-insight",
  storageBucket: "bike-insight.appspot.com",
  messagingSenderId: "201737700479",
  appId: "1:201737700479:web:0dd6c3b2a02614bb51ab4a",
};
//   apiKey: "AIzaSyCAWi8R4nYvUFnwjElvSsAlj2FbvrqRrL8",
//   authDomain: "bike-insight.firebaseapp.com",
//   projectId: "bike-insight",
//   storageBucket: "bike-insight.appspot.com",
//   messagingSenderId: "201737700479",
//   appId: "1:201737700479:web:0dd6c3b2a02614bb51ab4a",
// };

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
