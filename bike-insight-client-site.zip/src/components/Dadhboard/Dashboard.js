import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h1 className="md:text-[80px] text-[50px]">Welcome to the Dashboard</h1>
    </div>
  );
};

export default Dashboard;
